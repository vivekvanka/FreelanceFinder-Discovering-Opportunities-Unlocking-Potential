 ## 🎬 Demo Video

Watch the working demo of **FreelanceFinder – Discovering Opportunities, Unlocking Potential**:

🔗 [Click here to watch the demo on Google Drive](https://drive.google.com/file/d/1cCFjztuQAwYkV7q4tuVdWRs94WSwMn6t/view?usp=sharing)

